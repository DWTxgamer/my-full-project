{/* <div class="nav-bar" id="navbar">
<div class="top-section">
<a href="#">
<img src="./phoneUse.PNG" alt="" class="PhoneUseNav">
</a>

<a href="#">
<img src="./emailUse.PNG" alt="" class="EmailUseNav">
</a>
<div class="SearchButton">
<i class="fa-solid fa-magnifying-glass" id="search-button" onclick="search()"></i>
</div>
</div>

<div class="main-section" id="main-part">
<img src="./WebsiteLogo.PNG" alt="">

<div class="MainNavLinksHolder">
<a href="#" id="Active_link" class="Nav-links">Immigration</a>
<a href="#" class="Nav-links">Employment</a>
<a href="#" class="Nav-links">Human Resources</a>
<a href="#" class="Nav-links">Global Mobility</a>

</div>
</div>
 */}
